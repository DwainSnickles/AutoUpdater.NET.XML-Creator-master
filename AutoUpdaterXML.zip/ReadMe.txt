This is a standalone portable appplication.
AutoUpdater.Net XML Creator.
How to use:

Extract the zipfile AutoUpdaterXML.zip

Run the AutoUpdaterXML.exe

1) Required either manually enter the new file version that will be included in the <version>Tag. You can also click the get version button and browse to the exe file. If you see the redX change to Green checkmark the next button will be enabled. 

Click Next to continue

2) Required enter the URL path to where the XML will be on the server. Example https://myserver.com/MyUpdate.xml agian the green checkmark will enable the next button.

3) is a little tricky I will explain it here. There are 5 radio buttons you must select one. Note rb = RadioButton #
	rb 1) Allow user to decide? when using this it sets the <mandatory> tag to false you must add code to deal with this seperately. Running this will not create an error but update wont start. If used read xml find the <mandatory> tag if false then you will have to write the code to update manually.

	rb 2) Mandatory with all buttons displayed on update form

	rb 3) Mandatory Mode 1 removes the close button on the update form.

	rb 4) Forced update no update form shown and download start automatically
.
	rb 5) Only update if your app version is less than the minmum version    		Version listed on xml file.
	
	Final note all mandatory modes offer the minimum version if no minimum 	leave blank click next.

Click Next to continue.

4) Check sum is optional but if you choose to use it follow these steps.

	If you dont want the checksum leave blank click next to continue.

	You may enter you checksum manually if desired.

	1) Select checksum type desired using combobox.

	2) Click the folder icon browse to the directory of you updated app exe.

	3) Click the Calculate Checksum button the textbox below will have the 		   checksum for you.

Click Next to continue.

5) CommandLine args is option 
   
	If not needed leave blank click net to continue.

	If needed enter commandline argument here.

Click Next to continue.

6) Final step will create the XML file for you.

	1) Enter the XmlFileName .xml is optional if you forget the code will add 	   it for you.

	2) Click the folder button to select the folder you want to save the Xml 	   file to.

	3) Click the create XML file button to create the new XML file for you.

	4) If you want to view the file in browser Click the View XML File        	   button.

	5) Open XML Folder button will take you to where you created the file.

Your done click Exit button.


https://github.com/DwainSnickles/AutoUpdater.NET.XML-Creator-master/files/10938458/AutoUpdaterXML.zip